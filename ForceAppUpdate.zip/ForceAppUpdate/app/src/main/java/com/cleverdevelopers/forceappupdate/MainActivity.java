package com.cleverdevelopers.forceappupdate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.BuildConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

public class MainActivity extends AppCompatActivity {
    Button buttonUpdate;
    FirebaseRemoteConfig remoteConfig;
    private PackageInfo packageInfo = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonUpdate = findViewById(R.id.btn_check_for_update);

        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkForUpdate();
            }
        });
    }

    // Get App current Version
    private int getVersionCode(){
        try {

            packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return packageInfo.versionCode;
    }

    //Get Latest version from Firebase Remote Config
    private void checkForUpdate(){
        remoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(3600)
                .build();
        remoteConfig.setConfigSettingsAsync(configSettings);

        remoteConfig.fetchAndActivate().addOnCompleteListener(new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {
                final String latest_app_version = remoteConfig.getString("latest_app_version");
                if (Integer.parseInt(latest_app_version) > getVersionCode()){
                    //Open Alert Dialog
                    launchAlertDialog();
                }else{
                    Toast.makeText(getApplicationContext(), "No Update available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void launchAlertDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getResources().getString(R.string.app_name));
        builder.setMessage("Force App Up date recommends that you update to the latest version for a seamless and enhance performance of the application");
        builder.setIcon(R.drawable.ic_launcher_background);

        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Get App Package name
                final String pack_name = BuildConfig.APPLICATION_ID;
                //Launch playstore
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id="+
                        pack_name)));
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

}